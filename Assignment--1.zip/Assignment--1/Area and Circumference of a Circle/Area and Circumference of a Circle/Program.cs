﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_and_Circumference_of_a_Circle
{
    public class Program
    {
        static void Main(string[] args)
        {
           Class1 ac = new Class1();
            ac.AreaandCircumference();
            
            Console.ReadLine();
            
        }
    }
}
